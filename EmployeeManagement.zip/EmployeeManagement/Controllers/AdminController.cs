﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EmployeeManagement.BusinessObjects;
using EmployeeManagement.DAL;

namespace EmployeeManagement.Controllers
{
    public class AdminController : Controller
    {
        // GET: Admin

        public ActionResult dashboard()
        {
            return View();
        }
        public ActionResult esigroup()
        {
            return View();
        }
        public ActionResult ptgroup()
        {
            return View();
        }
        public ActionResult pfgroup()
        {
            return View();
        }
        public ActionResult bankdetails()
        {
            return View();
        }
        public ActionResult pfsetting()
        {
            return View();
        }
        public ActionResult retirementesetting()
        {
            return View();
        }
        public ActionResult salarystructure()
        {
            return View();
        }
        public ActionResult grademaster()
        {
            return View();
        }
        public ActionResult holidaymaster()
        {
            return View();
        }
        public ActionResult leavemaster()
        {
            return View();
        }
        public ActionResult sitemaster()
        {
            return View();
        }
        public ActionResult workordermaster()
        {
            return View();
        }
        public ActionResult pfrateeditor()
        {
            return View();
        }
        public ActionResult payheadmaster()
        {
            return View();
        }
        public ActionResult qualification()
        {
            return View();
        }
        public ActionResult lumpsumdefiner()
        {
            return View();
        }
        public ActionResult department()
        {
            return View();
        }
        public ActionResult designation()
        {
            var obj = new DesignationDataAccess();
            var list = obj.Getdesignation();
            return View(list);
        }
        public ActionResult occupation()
        {
            return View();
        }
        public ActionResult division()
        {
            return View();
        }
        public ActionResult attendence()
        {
            return View();
        }
        public ActionResult Payheadmapping()
        {
            return View();
        }
        public ActionResult view_employeee()
        {
            return View();
        }
        public ActionResult attendenceprocess()
        {
            return View();
        }
        public ActionResult leave()
        {
            return View();
        }
        [HttpPost]
        public ActionResult adddesignation(Designation designation)
        {
            DesignationDataAccess dataAccess = new DesignationDataAccess();
            dataAccess.insertdesignation(designation);
            return View("createdesignation");
        }
        public ActionResult createdesignation()
        {
            return View();
        }

        public ActionResult deletedesignation(string ids)
        {
            DesignationDataAccess dataAccess = new DesignationDataAccess();
            int id = 0;
            dataAccess.Deletedesignation(ids);

            ViewBag.Messsage = "Record Delete Successfully";
            return RedirectToAction("designation");
        }
        public ActionResult editdesignation(int id)
        {
            DesignationDataAccess dataAccess = new DesignationDataAccess();

            dataAccess.editdesignation(id);

            return RedirectToAction("designation");
        }
    }
}